# bot/main.py
# Signal-bot : мониторинг, сигналы, ликивид-фильтр и TP/SL-трекер

from __future__ import annotations

import asyncio
import logging
import os
from datetime import datetime
from pathlib import Path

import yaml
from aiogram import Bot
from aiogram.exceptions import TelegramNetworkError, TelegramRetryAfter
from dotenv import load_dotenv
from tinkoff.invest.exceptions import RequestError

from core.market_data import (
    get_last_candles,
    get_best_bid_ask,
    calc_spread_pct_from_quotes,
)
from core.probability import probability_of_success
from core.risk import calc_tp_sl
from core.strategy import ema_crossover
from core.universe import load_universe, schedule_universe_refresh

# ─────────── ENV / CONFIG ────────────────────────────────────────────────
load_dotenv()
BOT = Bot(token=os.getenv("TG_BOT_TOKEN"))
CHAT_ID = int(os.getenv("TG_CHAT_ID"))

CFG = yaml.safe_load(Path("config.yml").read_text(encoding="utf-8"))

logging.basicConfig(
    level=CFG.get("log_level", "INFO").upper(),
    format="%(asctime)s [%(levelname)s] %(message)s",
)

FAST_EMA     = CFG["strategy"]["fast"]
SLOW_EMA     = CFG["strategy"]["slow"]
TP_PCT       = CFG["take_profit_pct"]
SL_PCT       = CFG["stop_loss_pct"]
POLL_SECONDS = CFG["poll_interval_seconds"]
LOOKBACK_MIN = CFG["lookback_minutes"]
MAX_SPREAD   = CFG["liquidity"]["max_spread_pct"]
MIN_PROB     = CFG["probability"]["min_probability"]

UNIVERSE = load_universe(CFG.get("tickers", []))        # {ticker: figi}
logging.info("Старт. Всего тикеров: %d", len(UNIVERSE))

# ─────────── throttling для UNARY (лимит 550 req/min) ─────────────────────
_SEM = asyncio.Semaphore(550)

# ─────────── Telegram очередь ────────────────────────────────────────────
_SEND_Q: asyncio.Queue[str] = asyncio.Queue()

async def _telegram_worker() -> None:
    while True:
        msg = await _SEND_Q.get()
        try:
            await BOT.send_message(CHAT_ID, msg)
            await asyncio.sleep(1.2)          # flood-limit
        except TelegramRetryAfter as e:
            logging.warning("Flood-limit: %s s", e.retry_after)
            await asyncio.sleep(e.retry_after)
            _SEND_Q.put_nowait(msg)
        except TelegramNetworkError as e:
            logging.error("Telegram network error: %s", e)
            await asyncio.sleep(5)
            _SEND_Q.put_nowait(msg)
        finally:
            _SEND_Q.task_done()

# ─────────── обновление универсума по расписанию ─────────────────────────
def _update_universe(new_uni: dict[str, str]):
    global UNIVERSE
    UNIVERSE = new_uni
    logging.info("Universe обновлён: %d тикеров", len(UNIVERSE))

# ─────────── мониторинг одного тикера ────────────────────────────────────
async def _monitor_ticker(ticker: str) -> None:
    figi = UNIVERSE[ticker]
    while True:
        try:
            # 1) bid/ask через stream
            bid, ask = await get_best_bid_ask(figi)
            spread = calc_spread_pct_from_quotes(bid, ask)
            if spread is None:
                logging.debug("%s: spread N/A (нет bid/ask)", ticker)
                await asyncio.sleep(POLL_SECONDS)
                continue
            if spread > MAX_SPREAD:
                logging.debug("%s: spread %.4f > %.4f", ticker, spread, MAX_SPREAD)
                await asyncio.sleep(POLL_SECONDS)
                continue

            # 2) свечи (лимитируем семафором)
            async with _SEM:
                df = await get_last_candles(figi, minutes=LOOKBACK_MIN)
            if df.empty:
                logging.debug("%s: нет свежих свечей → skip", ticker)
                await asyncio.sleep(POLL_SECONDS)
                continue

            # 3) вероятность успеха
            ps = probability_of_success(df)
            if ps < MIN_PROB:
                logging.debug("%s: P=%.2f < %.2f", ticker, ps, MIN_PROB)
                await asyncio.sleep(POLL_SECONDS)
                continue

            # 4) стратегия
            signal = ema_crossover(df, fast=FAST_EMA, slow=SLOW_EMA)
            if not signal:
                await asyncio.sleep(POLL_SECONDS)
                continue

            price = df["close"].iloc[-1]
            tp, sl = calc_tp_sl(price, signal, TP_PCT, SL_PCT)
            txt = (
                f"[Сигнал] {signal.upper()} {ticker}\n"
                f"Цена: {price:.2f} ₽ | TP: {tp:.2f} | SL: {sl:.2f}\n"
                f"P≈{ps:.0%}, спред {spread:.2%}"
            )
            await _SEND_Q.put(txt)

        except RequestError as e:
            if "50002" in str(e):
                logging.warning("%s: FIGI не найден (%s)", ticker, figi)
            else:
                logging.exception("API-ошибка %s: %s", ticker, e)
        except Exception as e:
            logging.exception("Ошибка %s: %s", ticker, e)

        await asyncio.sleep(POLL_SECONDS)

# ─────────── заглушка трекера TP/SL ───────────────────────────────────────
async def _track_signals() -> None:
    await asyncio.Event().wait()

# ─────────── main ─────────────────────────────────────────────────────────
async def main():
    await asyncio.gather(
        _telegram_worker(),
        schedule_universe_refresh("06:15", on_refresh=_update_universe),
        *(_monitor_ticker(tk) for tk in UNIVERSE),
        _track_signals(),
    )

if __name__ == "__main__":
    asyncio.run(main())
