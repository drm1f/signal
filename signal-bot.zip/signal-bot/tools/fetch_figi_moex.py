import csv, requests

URL = (
    "https://iss.moex.com/iss/engines/stock/markets/shares/boards/TQBR/"
    "securities.csv?iss.meta=off&iss.only=securities&columns=SECID,NAME,FIGI"
)
outfile = "figi_rus_moex.csv"

resp = requests.get(URL, timeout=30)
resp.raise_for_status()

lines = resp.text.splitlines()
reader = csv.reader(lines, delimiter=';')

with open(outfile, "w", newline="") as f:
    wr = csv.writer(f)
    wr.writerow(["ticker", "figi", "name"])

    next(reader, None)          # пропускаем строку-заголовок
    for row in reader:
        # пропускаем пустые строки или неполные записи
        if len(row) < 3 or not row[0]:
            continue
        ticker, name, figi = row[:3]
        wr.writerow([ticker, figi, name])

print(f"Сохранено {sum(1 for _ in open(outfile))-1} бумаг → {outfile}")
