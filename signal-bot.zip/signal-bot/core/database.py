# core/database.py
import sqlite3
from pathlib import Path
from datetime import datetime

DB_PATH = Path("signals.db")

def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS signals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ticker TEXT NOT NULL,
                figi TEXT NOT NULL,
                direction TEXT NOT NULL,
                entry_price REAL NOT NULL,
                tp_price REAL NOT NULL,
                sl_price REAL NOT NULL,
                signal_time TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'ожидание',
                timeframe TEXT,
                trade_horizon_minutes INTEGER,
                confidence_score REAL,
                strategy TEXT,
                indicator_info TEXT,
                message_id INTEGER,
                comment TEXT
            )
        """)
        conn.commit()

def save_signal_to_db(ticker, figi, direction, entry, tp, sl,
                      timeframe=None, trade_horizon=None, score=None,
                      strategy="ema_crossover", indicators=None,
                      message_id=None, comment=None):
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO signals (
                ticker, figi, direction, entry_price, tp_price, sl_price,
                signal_time, status,
                timeframe, trade_horizon_minutes, confidence_score,
                strategy, indicator_info, message_id, comment
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            ticker, figi, direction, entry, tp, sl,
            datetime.utcnow().isoformat(), 'ожидание',
            timeframe, trade_horizon, score,
            strategy, indicators, message_id, comment
        ))
        conn.commit()
