# core/liquidity.py
# Быстрая проверка ликвидности: оцениваем BID/ASK‑спред

import logging
import os
from dotenv import load_dotenv
from tinkoff.invest import Client

load_dotenv()
_TOKEN = os.getenv("TIN_TOKEN")
if not _TOKEN:
    raise RuntimeError("Переменная окружения TIN_TOKEN не найдена – нужна для проверки ликвидности")

# ────────────────────────────────────────────────

def _price_to_float(pb_price):
    """Price from gRPC MoneyValue → float"""
    return pb_price.units + pb_price.nano / 1e9


def spread_ok(figi: str, threshold: float = 0.01) -> bool:
    """Возвращает True, если относительный спред <= threshold (например 0.01 = 1 %)"""
    try:
        with Client(_TOKEN) as client:
            ob = client.market_data.get_order_book(figi=figi, depth=1)
            if not ob.bids or not ob.asks:
                return False
            bid = _price_to_float(ob.bids[0].price)
            ask = _price_to_float(ob.asks[0].price)
            if bid <= 0 or ask <= 0:
                return False
            spread_pct = (ask - bid) / ((ask + bid) / 2)
            return spread_pct <= threshold
    except Exception as e:
        logging.warning(f"Не удалось проверить спред {figi}: {e}")
        return False
