# core/market_data.py
# --- рыночные данные (свечи + стакан) -------------------------------

from __future__ import annotations

import logging
import os
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from typing import Tuple

from dotenv import load_dotenv
from tinkoff.invest import (
    Client,
    CandleInterval,
    OrderBook,
)
from tinkoff.invest.utils import now

load_dotenv()
TOKEN = os.getenv("TINKOFF_TOKEN")

# === Кэш стаканов для расчёта спреда ===
_orderbooks: dict[str, OrderBook] = {}

# === Кэш свечей, чтобы не дёргать API одинаково ===
_candles: dict[Tuple[str, int], list] = defaultdict(list)


async def get_last_candles(figi: str, minutes: int):
    from tinkoff.invest.async_services import AsyncServices

    async with Client(TOKEN) as client:
        services: AsyncServices = await client.__aenter__()

        to_dt = datetime.now(timezone.utc)
        from_dt = to_dt - timedelta(minutes=minutes)

        candles = await services.market_data.get_candles(
            figi=figi,
            from_=from_dt,
            to=to_dt,
            interval=CandleInterval.CANDLE_INTERVAL_1_MIN,
        )

        df = _candles_to_df(candles.candles)
        df.attrs["figi"] = figi  # важно для расчёта спреда
        return df


def _candles_to_df(candles):
    import pandas as pd

    if not candles:
        return pd.DataFrame()

    df = pd.DataFrame(
        {
            "time": [c.time.replace(tzinfo=None) for c in candles],
            "open": [c.open.units + c.open.nano / 1e9 for c in candles],
            "high": [c.high.units + c.high.nano / 1e9 for c in candles],
            "low": [c.low.units + c.low.nano / 1e9 for c in candles],
            "close": [c.close.units + c.close.nano / 1e9 for c in candles],
            "volume": [c.volume for c in candles],
        }
    )

    return df


def update_orderbook(figi: str, ob: OrderBook) -> None:
    _orderbooks[figi] = ob


def get_orderbook(figi: str) -> OrderBook | None:
    return _orderbooks.get(figi)


def calc_spread_pct(df):
    figi = df.attrs.get("figi")
    ob = get_orderbook(figi)
    if not ob or not ob.bids or not ob.asks:
        logging.debug("%s: spread N/A (нет bid/ask)", df.attrs.get("ticker", "???"))
        return None

    bid = ob.bids[0].price.units + ob.bids[0].price.nano / 1e9
    ask = ob.asks[0].price.units + ob.asks[0].price.nano / 1e9
    spread = (ask - bid) / ((ask + bid) / 2)
    return spread
