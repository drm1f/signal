# core/universe.py
"""
Универсум инструментов МОEX/Tinkoff.

* load_universe()      – первичная загрузка каталога (csv) → {ticker: figi}
* reload_universe()    – пересчитывает файл-каталог заново (API → csv) и
                         возвращает актуальный словарь
* schedule_universe_refresh("HH:MM", on_refresh=callback)
                       – coroutine, которую можно запустить внутри
                         event-loop; раз в сутки вызывает reload_universe()
                         и опционально отдаёт результат в callback
"""

from __future__ import annotations

import asyncio
import csv
import datetime as _dt
import logging
import os
from pathlib import Path
from typing import Callable, Dict, Optional

from dotenv import load_dotenv
from tinkoff.invest import Client
from tinkoff.invest.schemas import InstrumentStatus

# ──────────────────────────────────────────────────────────────────────────────
#  базовые константы
# ──────────────────────────────────────────────────────────────────────────────
_CSV_FILE = Path(__file__).parent.parent / "figi_rus_tinkoff.csv"
_TARGET_CLASSES = {"TQBR", "TQTF"}       # высоколиквидные акции/фонды


# ──────────────────────────────────────────────────────────────────────────────
#  helpers
# ──────────────────────────────────────────────────────────────────────────────
def _save_list_to_csv(rows: list[tuple[str, str, str, str]]) -> None:
    with _CSV_FILE.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["ticker", "figi", "class_code", "name"])
        writer.writerows(rows)
    logging.info("Каталог FIGI сохранён: %s (%d rows)", _CSV_FILE, len(rows))


def _read_csv_to_dict() -> Dict[str, str]:
    if not _CSV_FILE.exists():
        return {}
    with _CSV_FILE.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        return {row["ticker"]: row["figi"] for row in reader}


# ──────────────────────────────────────────────────────────────────────────────
#  публичные функции
# ──────────────────────────────────────────────────────────────────────────────
def load_universe(tickers_filter: list[str] | None = None) -> Dict[str, str]:
    """
    Читает сохранённый CSV-каталог (без API-запросов).

    *tickers_filter* – если передан, вернёт только указанные тикеры.
    """
    uni = _read_csv_to_dict()
    if tickers_filter:
        uni = {t: f for t, f in uni.items() if t in tickers_filter}
    logging.info("Вселенная сформирована: %d тикеров", len(uni))
    return uni


def reload_universe() -> Dict[str, str]:
    """
    Полностью перезагружает каталог из API Tinkoff → csv → dict.
    """
    load_dotenv()
    token = os.getenv("TIN_TOKEN")
    if not token:
        raise RuntimeError("Переменная окружения TIN_TOKEN не задана")

    rows: list[tuple[str, str, str, str]] = []
    with Client(token) as client:
        resp = client.instruments.shares(
            instrument_status=InstrumentStatus.INSTRUMENT_STATUS_BASE
        )
        for share in resp.instruments:
            if share.class_code in _TARGET_CLASSES:
                rows.append((share.ticker, share.figi,
                             share.class_code, share.name))

    _save_list_to_csv(rows)
    return {r[0]: r[1] for r in rows}         # ticker → figi


def schedule_universe_refresh(
    time_hh_mm: str = "06:15",
    *,
    on_refresh: Optional[Callable[[Dict[str, str]], None]] = None,
) -> "asyncio.Task[None]":
    """
    Возвращает coroutine-job, которую нужно запустить внутри event-loop.

    Раз в сутки в заданное UTC-время перезагружает универсум.
    Передаёт результат в callback *on_refresh* (если он указан).
    """
    hour, minute = (int(x) for x in time_hh_mm.split(":"))

    async def _job() -> None:
        while True:
            now = _dt.datetime.utcnow()
            next_run = now.replace(hour=hour, minute=minute,
                                   second=0, microsecond=0)
            if next_run <= now:
                next_run += _dt.timedelta(days=1)

            await asyncio.sleep((next_run - now).total_seconds())

            logging.info("⟳ Обновление universе по расписанию…")
            new_uni = reload_universe()
            if on_refresh:
                on_refresh(new_uni)

    return _job()   # coroutine; запускать через create_task / gather
