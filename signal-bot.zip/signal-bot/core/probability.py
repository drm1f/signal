# core/probability.py
"""
O(n) эвристика вероятности «успеха» сигнала.

Пока что:
▪ считаем последние N срабатываний кроссовера «как есть»
▪ выигрыш = если за X баров после сигнала цена доходила до TP
▪ возвращаем долю выигрышных.  Статистика кешируется в pandas.DataFrame.
"""

import pandas as pd

# Сколько предыдущих пересечений берём для статистики
N_HISTORY = 60
# Сколько баров после сигнала смотрим (по тем же тайм-свечам)
FORWARD_BARS = 40

def probability_of_success(df: pd.DataFrame, signal: str) -> float:
    """
    df – DataFrame с колонкой 'close', 'ema_fast', 'ema_slow'
    signal – 'buy' | 'sell'
    """
    # ищем все точки пересечения
    cross_up   = (df["ema_fast"].shift(1) < df["ema_slow"].shift(1)) & \
                 (df["ema_fast"]          > df["ema_slow"])
    cross_down = (df["ema_fast"].shift(1) > df["ema_slow"].shift(1)) & \
                 (df["ema_fast"]          < df["ema_slow"])

    idx = df.index[cross_up if signal == "buy" else cross_down]
    if len(idx) == 0:
        return 0.5

    idx = idx[-N_HISTORY:]              # берём только N_HISTORY последних

    wins = 0
    for i in idx:
        entry_price = df.at[i, "close"]
        forward     = df.loc[i:].head(FORWARD_BARS)["close"]

        if signal == "buy":
            target = entry_price * 1.03   # 3 %  условно = TP
            stop   = entry_price * 0.985  # 1.5 % = SL
            hit = (forward >= target).any()
            fail= (forward <= stop).any()
        else:
            target = entry_price * 0.97
            stop   = entry_price * 1.015
            hit = (forward <= target).any()
            fail= (forward >= stop).any()

        if hit and not fail:
            wins += 1

    return (wins / len(idx)) if len(idx) else 0.5
