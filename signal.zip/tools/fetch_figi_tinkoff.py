# tools/fetch_figi_tinkoff.py

import os
import csv
import logging
from dotenv import load_dotenv
from tinkoff.invest import Client
from tinkoff.invest.schemas import InstrumentStatus

# Загружаем переменные окружения
load_dotenv()
TOKEN = os.getenv("TIN_TOKEN")

if not TOKEN:
    raise RuntimeError("Токен TIN_TOKEN не найден в .env")

# Классы ликвидных бумаг
TARGET_CLASS_CODES = {"TQBR", "TQTF"}


def fetch_and_save_figi_catalog(outfile="figi_rus_tinkoff.csv") -> int:
    """
    Загружает список бумаг с Tinkoff API и сохраняет в CSV.
    Возвращает количество сохранённых бумаг.
    """
    count = 0
    try:
        with Client(TOKEN) as client, open(outfile, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["ticker", "figi", "class_code", "name"])

            response = client.instruments.shares(
                instrument_status=InstrumentStatus.INSTRUMENT_STATUS_BASE
            )

            for share in response.instruments:
                if share.class_code in TARGET_CLASS_CODES:
                    writer.writerow([share.ticker, share.figi, share.class_code, share.name])
                    count += 1

        logging.info(f"Сохранено {count} бумаг → {outfile}")
    except Exception as e:
        logging.exception("Ошибка при получении бумаг из Tinkoff API")

    return count


# Точка входа для ручного запуска
if __name__ == "__main__":
    total = fetch_and_save_figi_catalog()
    print(f"Сохранено {total} бумаг")
