# bot/main.py
# Параллельный мониторинг бумаг и трекинг сигналов с очередью Telegram,
# фильтрацией по спреду и автоповтором FIGI-каталога.

import asyncio
import logging
import os
import sqlite3
from datetime import datetime

import yaml
from aiogram import Bot
from aiogram.exceptions import TelegramNetworkError, TelegramRetryAfter
from dotenv import load_dotenv
from tinkoff.invest.exceptions import RequestError

from core.market_data import (
    get_last_candles,
    calc_spread_pct,   #  ← новая функция
)
from core.risk import calc_tp_sl
from core.strategy import ema_crossover
from core.universe import load_universe, reload_universe  # reload загружает FIGI по расписанию

# ──────────────────────────────────────────────────────────────────────────────
# Конфиг и окружение
# ──────────────────────────────────────────────────────────────────────────────
load_dotenv()

CONFIG_PATH = os.getenv("CONFIG_PATH", "config.yml")
with open(CONFIG_PATH, encoding="utf-8") as f:
    CONFIG = yaml.safe_load(f)

BOT = Bot(token=os.getenv("TG_BOT_TOKEN"))
CHAT_ID = int(os.getenv("TG_CHAT_ID"))

FAST_EMA = CONFIG["strategy"].get("fast", 50)
SLOW_EMA = CONFIG["strategy"].get("slow", 200)
TP_PCT = CONFIG.get("take_profit_pct", 0.03)
SL_PCT = CONFIG.get("stop_loss_pct", 0.015)
POLL_INTERVAL = CONFIG.get("poll_interval_seconds", 60)
LOOKBACK_MINUTES = CONFIG.get("lookback_minutes", 300)
MAX_SPREAD = CONFIG.get("max_spread_pct", 0.005)  # 0.5 % по умолчанию
DB_PATH = "signals.db"

SEND_QUEUE: asyncio.Queue[str] = asyncio.Queue()
FULL_UNIVERSE = load_universe()
TICKERS = (
    CONFIG.get("tickers")
    if CONFIG.get("tickers")
    else list(FULL_UNIVERSE.keys())
)

# ──────────────────────────────────────────────────────────────────────────────
# Инициализация БД
# ──────────────────────────────────────────────────────────────────────────────
def init_db() -> None:
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS signals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ticker TEXT,
                figi TEXT,
                signal TEXT,
                entry_price REAL,
                tp_price REAL,
                sl_price REAL,
                timestamp TEXT,
                status TEXT
            )
        """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                signal_id INTEGER,
                event TEXT,
                price REAL,
                timestamp TEXT
            )
        """
        )


# ──────────────────────────────────────────────────────────────────────────────
# Telegram — единый worker c защитой от Flood Control
# ──────────────────────────────────────────────────────────────────────────────
async def telegram_worker() -> None:
    while True:
        msg = await SEND_QUEUE.get()
        try:
            await BOT.send_message(CHAT_ID, msg)
            await asyncio.sleep(1.2)  # 30 msg/сек безопасный предел
        except TelegramRetryAfter as e:
            logging.warning(f"Flood control → спим {e.retry_after} с")
            await asyncio.sleep(e.retry_after)
            await SEND_QUEUE.put(msg)  # повторим
        except TelegramNetworkError:
            logging.error("Timeout Telegram API; повтор через 5 с")
            await asyncio.sleep(5)
            await SEND_QUEUE.put(msg)
        finally:
            SEND_QUEUE.task_done()


# ──────────────────────────────────────────────────────────────────────────────
# Мониторинг одной акции
# ──────────────────────────────────────────────────────────────────────────────
async def monitor_ticker(ticker: str) -> None:
    figi = FULL_UNIVERSE.get(ticker)
    if not figi:
        logging.warning(f"{ticker}: нет FIGI → исключён")
        return

    while True:
        try:
            # проверяем спред
            spread = calc_spread_pct(figi)
            if spread is None or spread > MAX_SPREAD:
                logging.debug(f"{ticker}: спред {spread} > {MAX_SPREAD}")
                await asyncio.sleep(POLL_INTERVAL)
                continue

            df = await get_last_candles(figi, minutes=LOOKBACK_MINUTES)
            if df.empty:
                logging.debug(f"{ticker}: пустые данные свечей")
                await asyncio.sleep(POLL_INTERVAL)
                continue

            signal = ema_crossover(df, fast=FAST_EMA, slow=SLOW_EMA)
            if not signal:
                await asyncio.sleep(POLL_INTERVAL)
                continue

            price = df["close"].iloc[-1]
            tp, sl = calc_tp_sl(price, signal, TP_PCT, SL_PCT)

            text = (
                f"[Сигнал] {signal.upper()} {ticker}\n"
                f"Цена: {price:.2f} ₽\n"
                f"TP: {tp:.2f} ₽ (+{TP_PCT*100:.1f} %)\n"
                f"SL: {sl:.2f} ₽ (−{SL_PCT*100:.1f} %)\n"
                f"⏳ Ожидаем срабатывания…"
            )
            await SEND_QUEUE.put(text)

            with sqlite3.connect(DB_PATH) as conn:
                conn.execute(
                    """
                    INSERT INTO signals
                    (ticker, figi, signal, entry_price, tp_price, sl_price, timestamp, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, 'ожидание')
                """,
                    (
                        ticker,
                        figi,
                        signal,
                        price,
                        tp,
                        sl,
                        datetime.now().isoformat(),
                    ),
                )

        except RequestError as e:
            if "50002" in str(e):
                logging.warning(f"{ticker}: FIGI не найден")
            else:
                logging.exception(f"{ticker}: Tinkoff API error → {e}")
        except Exception as exc:
            logging.exception(f"{ticker}: неожиданная ошибка → {exc}")

        await asyncio.sleep(POLL_INTERVAL)


# ──────────────────────────────────────────────────────────────────────────────
# Трекинг открытых сигналов
# ──────────────────────────────────────────────────────────────────────────────
async def track_signals_loop() -> None:
    while True:
        with sqlite3.connect(DB_PATH) as conn:
            rows = conn.execute(
                """
                SELECT id, ticker, figi, signal, tp_price, sl_price
                FROM signals WHERE status='ожидание'
            """
            ).fetchall()

        for _id, ticker, figi, signal, tp, sl in rows:
            try:
                df = await get_last_candles(figi, minutes=1)
                if df.empty:
                    continue

                price = df["close"].iloc[-1]
                status = None
                if signal == "buy" and price >= tp:
                    status = "tp"
                elif signal == "buy" and price <= sl:
                    status = "sl"
                elif signal == "sell" and price <= tp:
                    status = "tp"
                elif signal == "sell" and price >= sl:
                    status = "sl"

                if status:
                    with sqlite3.connect(DB_PATH) as conn:
                        conn.execute(
                            "UPDATE signals SET status=? WHERE id=?",
                            (status, _id),
                        )
                        conn.execute(
                            "INSERT INTO logs(signal_id,event,price,timestamp) VALUES(?,?,?,?)",
                            (_id, status, price, datetime.now().isoformat()),
                        )
                    await SEND_QUEUE.put(
                        f"📈 {ticker} достиг {status.upper()} — {price:.2f} ₽"
                    )
            except Exception as e:
                logging.error(f"Трекинг {ticker}: {e}")

        await asyncio.sleep(30)


# ──────────────────────────────────────────────────────────────────────────────
# Периодическое обновление FIGI-каталога
# ──────────────────────────────────────────────────────────────────────────────
async def universe_refresher() -> None:
    """
    Раз в 7 дней перезагружает figi_rus_tinkoff.csv
    и валидирует FIGI через reload_universe().
    """
    while True:
        await asyncio.sleep(60 * 60 * 24 * 7)
        await SEND_QUEUE.put("♻️  Обновляю FIGI-каталог…")
        reload_universe()  # эта функция внутри core/universe скачивает новый CSV
        await SEND_QUEUE.put("✅ FIGI-каталог обновлён")


# ──────────────────────────────────────────────────────────────────────────────
# main
# ──────────────────────────────────────────────────────────────────────────────
async def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
    )
    init_db()
    logging.info(f"Всего тикеров к мониторингу: {len(TICKERS)}")

    await asyncio.gather(
        telegram_worker(),
        track_signals_loop(),
        universe_refresher(),
        *[monitor_ticker(t) for t in TICKERS],
    )


if __name__ == "__main__":
    asyncio.run(main())
