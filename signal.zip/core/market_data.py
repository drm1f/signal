# core/market_data.py
# ──────────────────────────────────────────────────────────────────────────────
# Работа с историческими свечами и расчёт спреда по стакану
# ──────────────────────────────────────────────────────────────────────────────
from datetime import datetime, timedelta
from typing import Optional
import os

import pandas as pd
from tinkoff.invest import Client, CandleInterval

# Токен Tinkoff из .env
TOKEN = os.getenv("TIN_TOKEN")
if not TOKEN:
    raise RuntimeError("Переменная окружения TIN_TOKEN не найдена")

# ──────────────────────────────────────────────────────────────────────────────
# Загрузка свечей
# ──────────────────────────────────────────────────────────────────────────────
async def get_last_candles(figi: str, minutes: int = 60) -> pd.DataFrame:
    """
    Возвращает minute-свечи за последние `minutes` минут.
    Асинхронная обёртка поверх синхронного gRPC-клиента.
    """
    now = datetime.utcnow()
    start = now - timedelta(minutes=minutes)

    with Client(TOKEN) as client:
        candles = list(
            client.get_all_candles(
                figi=figi,
                from_=start,
                to=now,
                interval=CandleInterval.CANDLE_INTERVAL_1_MIN,
            )
        )

    if not candles:
        # Пустой DataFrame с нужными колонками
        return pd.DataFrame(columns=["open", "high", "low", "close", "volume"])

    df = pd.DataFrame(
        {
            "time": [c.time for c in candles],
            "open": [c.open.units + c.open.nano / 1e9 for c in candles],
            "high": [c.high.units + c.high.nano / 1e9 for c in candles],
            "low": [c.low.units + c.low.nano / 1e9 for c in candles],
            "close": [c.close.units + c.close.nano / 1e9 for c in candles],
            "volume": [c.volume for c in candles],
        }
    )
    df["time"] = pd.to_datetime(df["time"])
    return df.set_index("time")


# ──────────────────────────────────────────────────────────────────────────────
# Расчёт относительного спреда
# ──────────────────────────────────────────────────────────────────────────────
def calc_spread_pct(figi: str, depth: int = 1) -> Optional[float]:
    """
    Считает относительный спред:
        (best_ask - best_bid) / mid_price

    • Возвращает долю (0.005 = 0.5 %).  
    • Если нет стакана или ошибка — `None`, чтобы вызывающий код
      мог пропустить инструмент.
    """
    try:
        with Client(TOKEN) as client:
            ob = client.market_data.get_order_book(figi=figi, depth=depth)

        if not ob.asks or not ob.bids:
            return None

        best_ask = ob.asks[0].price.units + ob.asks[0].price.nano / 1e9
        best_bid = ob.bids[0].price.units + ob.bids[0].price.nano / 1e9
        mid = (best_ask + best_bid) / 2
        if mid == 0:
            return None

        return (best_ask - best_bid) / mid
    except Exception:
        return None
