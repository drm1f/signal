# core/universe.py
import csv
import logging
from pathlib import Path
from tinkoff.invest import Client
from tinkoff.invest.exceptions import RequestError
from dotenv import load_dotenv
import os

load_dotenv()
TOKEN = os.getenv("TIN_TOKEN")
_CSV_PATH = Path(__file__).parent.parent / "figi_rus_tinkoff.csv"

def _validate_figi(figi: str) -> bool:
    """Пробуем запросить маркер цены; если инструмент недоступен – ловим исключение."""
    try:
        with Client(TOKEN) as client:
            client.market_data.get_last_prices(figi=[figi])
        return True
    except RequestError:
        return False

def load_universe() -> dict[str, str]:
    """Читает CSV, валидирует FIGI, возвращает {ticker: figi}."""
    if not _CSV_PATH.exists():
        logging.warning(f"Файл {_CSV_PATH} не найден – universe пуст.")
        return {}

    universe: dict[str, str] = {}
    with _CSV_PATH.open(newline='', encoding='utf-8') as f:
        for row in csv.DictReader(f):
            ticker, figi = row["ticker"], row["figi"]
            if _validate_figi(figi):
                universe[ticker] = figi
            else:
                logging.debug(f"Пропущен {ticker} – FIGI недоступен.")
    logging.info(f"Всего валидных бумаг: {len(universe)}")
    return universe

# --- Важно для bot/main.py ---
def reload_universe() -> dict[str, str]:
    """Пере-читаем CSV и возвращаем обновлённый словарь."""
    return load_universe()
