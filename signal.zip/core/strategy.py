# core/strategy.py

import pandas_ta as ta
import pandas as pd

def ema_crossover(df, fast=50, slow=200):
    """
    Проверка сигнала на пересечение EMA:
    - "BUY", если быстрая EMA пересекает медленную снизу вверх
    - "SELL", если сверху вниз
    """
    df["ema_fast"] = ta.ema(df["close"], length=fast)
    df["ema_slow"] = ta.ema(df["close"], length=slow)

    if len(df) < 2:
        return None

    prev = df.iloc[-2]
    last = df.iloc[-1]

    if any(pd.isna(x) for x in [
        prev.ema_fast, prev.ema_slow, last.ema_fast, last.ema_slow
    ]):
        return None

    if prev.ema_fast < prev.ema_slow and last.ema_fast > last.ema_slow:
        return "BUY"
    if prev.ema_fast > prev.ema_slow and last.ema_fast < last.ema_slow:
        return "SELL"
    return None
