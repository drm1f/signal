import os
from tinkoff.invest import Client, OrderDirection, OrderType

TOKEN = os.getenv("TIN_TOKEN")

async def place_bracket_order(
    figi: str,
    lots: int,
    entry_price: float,
    tp_price: float,
    sl_price: float,
    direction: str
):
    """
    Выполняет рыночный вход и ставит лимитный TP + стоп-лимит SL.
    """
    dir_enum = OrderDirection.BUY if direction == "BUY" else OrderDirection.SELL
    with Client(TOKEN) as client:
        # рыночный вход
        client.orders.post_order(
            figi=figi,
            quantity=lots,
            direction=dir_enum,
            order_type=OrderType.MARKET,
            order_id="entry"
        )
        # тейк-профит
        client.orders.post_order(
            figi=figi,
            quantity=lots,
            price=tp_price,
            direction=OrderDirection.SELL if dir_enum == OrderDirection.BUY else OrderDirection.BUY,
            order_type=OrderType.LIMIT,
            order_id="tp"
        )
        # стоп-лимит
        client.orders.post_order(
            figi=figi,
            quantity=lots,
            price=sl_price,
            direction=OrderDirection.SELL if dir_enum == OrderDirection.BUY else OrderDirection.BUY,
            order_type=OrderType.STOP_LIMIT,
            order_id="sl"
        )
