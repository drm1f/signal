def calc_tp_sl(
    entry_price: float,
    direction: str,
    take_pct: float = 0.03,
    stop_pct: float = 0.015
) -> tuple[float, float]:
    """
    Рассчитывает цены TP и SL в зависимости от направления.
    """
    if direction == "BUY":
        tp = round(entry_price * (1 + take_pct), 2)
        sl = round(entry_price * (1 - stop_pct), 2)
    else:
        tp = round(entry_price * (1 - take_pct), 2)
        sl = round(entry_price * (1 + stop_pct), 2)
    return tp, sl
